package com.example.menabil_elida_mateescu_elena_1082.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.menabil_elida_mateescu_elena_1082.AdaugareTimbre;
import com.example.menabil_elida_mateescu_elena_1082.R;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TimbruAdapter  extends ArrayAdapter<Timbru> {
    private Context context;
    private int resoruce;
    private List<Timbru> timbre;
    private LayoutInflater layoutInflater;

    public TimbruAdapter(@NonNull Context context, int resource, List<Timbru> timbre, LayoutInflater layoutInflater) {
        super(context, resource, timbre);
        this.context = context;
        this.resoruce= resource;
        this.timbre = timbre;
        this.layoutInflater = layoutInflater;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        @SuppressLint("ViewHolder")
        View view = layoutInflater.inflate(resoruce, parent, false);
        Timbru timbru = timbre.get(position);
        if(timbru != null) {
            addDenumire(view, timbru.getDenumire());
            addSerieInventar(view, timbru.getSerieTimbru());
            addData(view, timbru.getDataCreatiei());
            addPret(view, timbru.getPret());
            addUzura(view, timbru.getUzura());
        }
        return view;
    }

    private void addDenumire(View view, String denumire) {
        TextView textView = view.findViewById(R.id.tv_denumire);
        if(denumire != null && !denumire.trim().isEmpty()) {
            textView.setText(denumire);
        } else {
            textView.setText(R.string.no_content_message);
        }
    }

    private void addSerieInventar(View view, String serieTimbru) {
        TextView textView = view.findViewById(R.id.tv_serieTimbru);
        if(serieTimbru != null && !serieTimbru.trim().isEmpty()) {
            textView.setText(serieTimbru);
        } else {
            textView.setText(R.string.no_content_message);
        }
    }

    private void addData(View view, Date data) {
        TextView textView = view.findViewById(R.id.tv_data);
        if(data != null) {
            textView.setText(new SimpleDateFormat(AdaugareTimbre.DATE_FORMAT, Locale.US).format(data));
        } else {
            textView.setText(R.string.no_content_message);
        }
    }

    private void addPret(View view, Double valoare) {
        TextView textView = view.findViewById(R.id.tv_pret);
        if(valoare != null) {
            textView.setText(String.valueOf(valoare));
        } else {
            textView.setText(R.string.no_content_message);
        }
    }

    private void addUzura(View view, String uzura)
    {
        TextView textView = view.findViewById(R.id.tv_uzura);
        if(uzura!=null&& !uzura.trim().isEmpty()) {
            textView.setText(uzura);
        } else {
            textView.setText(R.string.no_content_message);
        }
    }



}
