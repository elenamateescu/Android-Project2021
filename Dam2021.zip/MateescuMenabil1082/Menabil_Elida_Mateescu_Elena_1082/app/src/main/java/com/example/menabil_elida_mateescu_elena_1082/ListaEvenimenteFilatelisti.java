package com.example.menabil_elida_mateescu_elena_1082;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;


public class ListaEvenimenteFilatelisti extends AppCompatActivity {

    ListView list=null;

    String [] web = new String[]{
            getString(R.string.arraay1) + "\n" + getString(R.string.array2) +
                    getString(R.string.array3) +
                    getString(R.string.array4)+
            getString(R.string.array5)};
    Integer[] imageId = {
            R.drawable.itemone,
            R.drawable.itemtwo


    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_eveneminte_fitateristi);

        CustomList adapter = new
                CustomList(ListaEvenimenteFilatelisti.this, web, imageId);
        list=findViewById(R.id.lv_evenimente);
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                Toast.makeText(ListaEvenimenteFilatelisti.this, getString(R.string.lista_ev_string1) +web[+ position], Toast.LENGTH_SHORT).show();

            }
        });

    }


}