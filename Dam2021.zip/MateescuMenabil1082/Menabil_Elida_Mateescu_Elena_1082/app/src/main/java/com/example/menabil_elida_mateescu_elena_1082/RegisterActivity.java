package com.example.menabil_elida_mateescu_elena_1082;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class RegisterActivity extends AppCompatActivity implements  View.OnClickListener{

    Button register_activiry_confirmati;
    Button register_activity_renuntati;
    EditText register_activity_username;
    EditText register_activity_email;
    EditText register_activity_password;
    EditText register_activity_confirm_password;

    FirebaseAuth fAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        register_activity_email=findViewById(R.id.activity_register_email);
        register_activity_username=findViewById(R.id.activity_register_user_name);
        register_activity_password=findViewById(R.id.activity_register_password);
        register_activity_confirm_password=findViewById(R.id.activity_register_confirm_password);

        register_activiry_confirmati=findViewById(R.id.activity_register_confirmare);
        register_activity_renuntati=findViewById(R.id.activity_register_renuntati);

        register_activity_renuntati.setOnClickListener(v -> {
            Toast.makeText(getApplicationContext(), R.string.redirect,Toast.LENGTH_SHORT).show();
            Intent newIntent = new Intent(RegisterActivity.this, LogInActivity.class);
            startActivity(newIntent);
        });

        register_activiry_confirmati.setOnClickListener(v -> {
             if(verificareDateIntrare())
             {
                 String email =register_activity_email.getText().toString().trim();
                 String passwrod=register_activity_password.getText().toString().trim();
                 fAuth.createUserWithEmailAndPassword(email,passwrod).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                     @Override
                     public void onComplete(@NonNull Task<AuthResult> task) {
                         if(task.isSuccessful()) {
                             Toast.makeText(getApplicationContext(), "Welcome!", Toast.LENGTH_LONG).show();
                             Toast.makeText(getApplicationContext(), R.string.register_activity_success_message, Toast.LENGTH_LONG).show();
                             Intent newIntent = new Intent(RegisterActivity.this, LogInActivity.class);
                             startActivity(newIntent);
                         }
                     }
                 });
             }

        });
    }

    boolean esteEmail(EditText text)
    {
        CharSequence email=text.getText().toString();
        return(!TextUtils.isEmpty(email) && Patterns.EMAIL_ADDRESS.matcher(email).matches());
    }

    boolean verificareDateIntrare()
    {
        if(esteGol(register_activity_username))
        {
            register_activity_username.setError(getString(R.string.register_activity_eroare_username));
            return false;
        }

        if(esteGol(register_activity_password) && register_activity_password.getText().toString().length()<4)
        {
            register_activity_password.setError(getString(R.string.register_activity_eroare_parola));
            return false;

        }

        if(esteGol(register_activity_confirm_password) && register_activity_confirm_password.getText().toString().equals(register_activity_password.getText().toString()))
        {
            register_activity_confirm_password.setError(getString(R.string.register_activity_eroare_parole_neconforme));
            return false;

        }
        if(!esteEmail(register_activity_email)) {
            register_activity_email.setError(getString(R.string.register_activity_eroare_email_invalid));
            return false;

        }

        return true;
    }

    boolean esteGol(EditText text)
    {
        CharSequence str=text.getText().toString();
        return TextUtils.isEmpty(str);
    }

    @Override
    public void onClick(View v) {

    }
}


