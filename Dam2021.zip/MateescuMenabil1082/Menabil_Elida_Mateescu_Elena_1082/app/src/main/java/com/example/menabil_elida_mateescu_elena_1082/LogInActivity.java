package com.example.menabil_elida_mateescu_elena_1082;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import android.text.TextUtils;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LogInActivity extends AppCompatActivity implements View.OnClickListener{

    Button login_activity_btn_login;
    Button login_activity_btn_signin;
    EditText login_activity_edt_user;
    EditText login_activity_edit_password;
    TextView login_activity_save_data;
    TextView login_activity_restore_data;

    FirebaseAuth  fAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        login_activity_btn_login=findViewById(R.id.activity_log_in_log_in);
        login_activity_btn_signin=findViewById(R.id.activity_login_signin);

        login_activity_edit_password=findViewById(R.id.activity_login_password);
        login_activity_edt_user=findViewById(R.id.activity_login_user);

        login_activity_save_data=findViewById(R.id.textViewSalvare);
        login_activity_restore_data=findViewById(R.id.textViewRestaurare);

        fAuth= FirebaseAuth.getInstance();

        login_activity_btn_login.setOnClickListener(v -> {
            SharedPreferences sharedPreferences= getSharedPreferences("User log in info", Context.MODE_PRIVATE);

            String email = login_activity_edt_user.getText().toString().trim();
            String password = login_activity_edit_password.getText().toString().trim();

            if(!TextUtils.isEmpty(email)&&!TextUtils.isEmpty(email)){

                fAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {

                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

                            Toast.makeText(getApplicationContext(),
                                    R.string.redirect,Toast.LENGTH_SHORT).show();
                            Intent myIntent = new Intent(getBaseContext(),   MainActivity.class);
                            startActivity(myIntent);
                        }
                    }});

            }else {
                Toast.makeText(getApplicationContext(), R.string.login_activity_redirect,
                        Toast.LENGTH_SHORT).show();
            }

        });

        login_activity_btn_signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),
                        R.string.redirect,Toast.LENGTH_SHORT).show();
                Intent myIntent = new Intent(getBaseContext(),   RegisterActivity.class);
                startActivity(myIntent);

            }
        });

        login_activity_save_data.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sharedPreferences = getSharedPreferences("User log in info", Context.MODE_PRIVATE);

                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("user", login_activity_edt_user.getText().toString());
                editor.putString("password", login_activity_edit_password.getText().toString());
                editor.apply();

                Toast.makeText(getApplicationContext(), "Saved!", Toast.LENGTH_SHORT).show();
            }
        });

        login_activity_restore_data.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sharedPreference= getSharedPreferences("User log in info", Context.MODE_PRIVATE);
                String user=sharedPreference.getString("user","");
                String password=sharedPreference.getString("password","");

                login_activity_edt_user.setText(user);
                login_activity_edit_password.setText(password);
            }
        });
    }

    @Override
    public void onClick(View v) {

    }
}