package com.example.menabil_elida_mateescu_elena_1082;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ContacteazaDezvolatatoriiAplicatiei extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacteaza_dezvolatatorii_aplicatiei);
    }
}