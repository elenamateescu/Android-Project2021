package com.example.menabil_elida_mateescu_elena_1082;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

public class EvaluareAplicatie extends AppCompatActivity {

    RatingBar activity_evaluare_aplicatie_rating;
    EditText activity_evaluare_aplicatie_info;
    Button activity_evaluare_aplicatie_trimitere;
    TextView activity_evaluare_aplicatie_tv_scale;

    @SuppressLint("IntentReset")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_evaluare_applicatie);

        activity_evaluare_aplicatie_rating=findViewById(R.id.evaluare_aplicatie_rating_app);
        activity_evaluare_aplicatie_info=findViewById(R.id.evaluare_aplicatie_edt_info);
        activity_evaluare_aplicatie_trimitere=findViewById(R.id.evaluare_aplicatie_submit_button);
        activity_evaluare_aplicatie_tv_scale=findViewById(R.id.evaluare_aplicatie_tv_rate);

        activity_evaluare_aplicatie_rating.setOnRatingBarChangeListener((ratingBar, rating, fromUser) -> {
            activity_evaluare_aplicatie_tv_scale.setText(String.valueOf(rating));
            switch ((int)ratingBar.getRating()){
                case 1:
                    activity_evaluare_aplicatie_tv_scale.setText(R.string.evaluaza_aplicatie_star1);
                    break;
                case 2:
                    activity_evaluare_aplicatie_tv_scale.setText(R.string.evalueaza_aplicatie_star2);
                    break;
                case 3:
                    activity_evaluare_aplicatie_tv_scale.setText(R.string.evalueaza_aplicatie_star3);
                    break;
                case 4:
                    activity_evaluare_aplicatie_tv_scale.setText(R.string.evalueaza_aplicatie_star4);
                    break;
                case 5:
                    activity_evaluare_aplicatie_tv_scale.setText(R.string.evalueaza_aplicatie_star5);
                    break;
            }
        });

        activity_evaluare_aplicatie_trimitere.setOnClickListener(v -> {
            if(activity_evaluare_aplicatie_info.getText().toString().isEmpty())
            {


                Toast.makeText(getApplicationContext(), R.string.activity_evalueaza_applicatie_err,Toast.LENGTH_SHORT).show();
            }else{
                Log.i(getString(R.string.trimitere_email), String.valueOf(R.string.empty_string));
                String[] TO = {getString(R.string.email_dezvoltator)};
                String[] CC = {String.valueOf(R.string.empty_string)};
                Intent emailIntent = new Intent(Intent.ACTION_SEND);// folosim clasa corespunzatoare pentru implementarea metodei

                emailIntent.setData(Uri.parse(getString(R.string.activity_evalueaza_mailto)));
                emailIntent.setType(getString(R.string.actity_evalueaza_textplain));
                emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
                emailIntent.putExtra(Intent.EXTRA_CC, CC);
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.activity_evalueaza_mail_subject));
                emailIntent.putExtra(Intent.EXTRA_TEXT, getString(R.string.activity_evalueaza_corp_mail1) +(int)activity_evaluare_aplicatie_rating.getRating()+"(" +activity_evaluare_aplicatie_tv_scale.getText().toString()+ ")" + getString(R.string.activity_evalueaza_corp_mail2)
                        + " "+ activity_evaluare_aplicatie_info.getText().toString() );

                try {
                    startActivity(Intent.createChooser(emailIntent, getString(R.string.activity_evalueaza_mesaj_pentru_success)));
                    finish();
                    Log.i(getString(R.string.activity_evalueaza_mesaj_erroare_trimitere), getString(R.string.empty_string));
                } catch (android.content.ActivityNotFoundException ex) {
                    Toast.makeText(getApplicationContext(), R.string.activity_evalueaza_mesaj_eroare_client, Toast.LENGTH_SHORT).show();
                }



            }
        });

    }
}