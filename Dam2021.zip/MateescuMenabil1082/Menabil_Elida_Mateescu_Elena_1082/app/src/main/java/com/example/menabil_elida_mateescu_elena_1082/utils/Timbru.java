package com.example.menabil_elida_mateescu_elena_1082.utils;

import android.os.Parcel;
import android.os.Parcelable;
import com.example.menabil_elida_mateescu_elena_1082.AdaugareTimbre;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Timbru implements Parcelable {
    private String denumire;
    private String serieTimbru;
    private Date dataCreatiei;
    private double pret;
    private String uzura;


    public Timbru(String denumire, String serieTimbru, Date dataCreatiei, double pret, String uzura) {
        this.denumire = denumire;
        this.serieTimbru = serieTimbru;
        this.dataCreatiei = dataCreatiei;
        this.pret = pret;
        this.uzura = uzura;
    }


    protected Timbru(Parcel in) {
        denumire = in.readString();
        serieTimbru = in.readString();
        try {
            dataCreatiei = new SimpleDateFormat(AdaugareTimbre.DATE_FORMAT, Locale.US).parse(in.readString());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        pret = in.readDouble();
        uzura = in.readString();
    }

    public static final Creator<Timbru> CREATOR = new Creator<Timbru>() {
        @Override
        public Timbru createFromParcel(Parcel in) {
            return new Timbru(in);
        }

        @Override
        public Timbru[] newArray(int size) {
            return new Timbru[size];
        }
    };

    public String getDenumire() {
        return denumire;
    }

    public void setDenumire(String denumire) {
        this.denumire = denumire;
    }

    public String getSerieTimbru() {
        return serieTimbru;
    }

    public void setSerieTimbru(String serieTimbru) {
        this.serieTimbru = serieTimbru;
    }

    public Date getDataCreatiei() {
        return dataCreatiei;
    }

    public void setDataCreatiei(Date dataCreatiei) {
        this.dataCreatiei = dataCreatiei;
    }

    public double getPret() {
        return pret;
    }

    public void setPret(double pret) {
        this.pret = pret;
    }

    public String getUzura() {
        return uzura;
    }

    public void setUzura(String uzura) {
        this.uzura = uzura;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(denumire);
        dest.writeString(serieTimbru);
        dest.writeString(new SimpleDateFormat(AdaugareTimbre.DATE_FORMAT,Locale.US).format(dataCreatiei));

        dest.writeDouble(pret);
        dest.writeString(uzura);
    }

    @Override
    public String toString() {
        return "Timbru{" +
                "denumire='" + denumire + '\'' +
                ", serieTimbru='" + serieTimbru + '\'' +
                ", dataCreatiei=" + dataCreatiei +
                ", pret=" + pret +
                ", uzura='" + uzura + '\'' +
                '}';
    }
}
