package com.example.menabil_elida_mateescu_elena_1082;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.menabil_elida_mateescu_elena_1082.utils.Timbru;
import com.example.menabil_elida_mateescu_elena_1082.utils.TimbruAdapter;

import java.util.ArrayList;
import java.util.List;

import static com.example.menabil_elida_mateescu_elena_1082.AdaugareTimbre.RESULT_DELETE;

public class ListaTimbre extends AppCompatActivity {

    public static final String UPDATE_OBIECT = "update";
    public static final int REQUEST_CODE_UPDATE = 204;
    List<Timbru> listaTimbre = new ArrayList<>();
    ListView lvTimbre;
    private int selectedIndex ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_timbre);
        if(getIntent().getParcelableArrayListExtra(MainActivity.LISTA_TIMBRE) != null) {
            listaTimbre = getIntent().getParcelableArrayListExtra(MainActivity.LISTA_TIMBRE);
        }
        initComponents();
    }

    private void initComponents() {
        lvTimbre = findViewById(R.id.lv_timbre);
        TimbruAdapter adapter = new TimbruAdapter(getApplicationContext(), R.layout.timbre_adapter,
                listaTimbre, getLayoutInflater());
        lvTimbre.setAdapter(adapter);

        lvTimbre.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selectedIndex = position;
                Intent intent = new Intent(getApplicationContext(), AdaugareTimbre.class);
                intent.putExtra(UPDATE_OBIECT, listaTimbre.get(position));
                startActivityForResult(intent, REQUEST_CODE_UPDATE);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REQUEST_CODE_UPDATE && resultCode == RESULT_OK &&data!= null) {
            Timbru timbru = data.getParcelableExtra(AdaugareTimbre.ADAUGA_TIMBRU);
            listaTimbre.set(selectedIndex, timbru);
            notifyAdapter();
        } else if(requestCode == REQUEST_CODE_UPDATE && resultCode == RESULT_DELETE && data != null) {
            listaTimbre.remove(selectedIndex);
            notifyAdapter();
        }
    }

    public void notifyAdapter() {
        TimbruAdapter adapter = (TimbruAdapter) lvTimbre.getAdapter();
        adapter.notifyDataSetChanged();
    }
}