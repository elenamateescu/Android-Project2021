package com.example.menabil_elida_mateescu_elena_1082;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.menabil_elida_mateescu_elena_1082.utils.Timbru;

import java.util.ArrayList;
import android.widget.Button;
public class MainActivity extends AppCompatActivity {
    public static final int REQUEST_CODE_ADAUGA = 200;
    public static final String LISTA_TIMBRE = "listatimbre";
    public static final int REQUEST_CODE_LISTA = 201;
    ArrayList<Timbru> timbreLista=new ArrayList<>();
    public static final int RESULT_DELETE = 4;


    ImageButton main_activity_btn_Evalueaza_Applicatie;
    ImageButton main_activity_btn_adauga_timbru;
    ImageButton main_activity_btn_lista_timbre;
    ImageButton main_activity_btn_lista_evenimte;

    Button main_activity_btn_json;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        main_activity_btn_Evalueaza_Applicatie=findViewById(R.id.main_activity_evalueaza);
        main_activity_btn_Evalueaza_Applicatie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(getApplicationContext(), R.string.redirect,Toast.LENGTH_SHORT).show();
                Intent newIntent = new Intent(MainActivity.this, EvaluareAplicatie.class);
                startActivity(newIntent);
            }
        });

        main_activity_btn_adauga_timbru=findViewById(R.id.main_activity_adauga_timbru);
        main_activity_btn_adauga_timbru.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), AdaugareTimbre.class);
                startActivityForResult(intent,REQUEST_CODE_ADAUGA);
            }
        });

        main_activity_btn_lista_timbre=findViewById(R.id.main_activity_list);
        main_activity_btn_lista_timbre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ListaTimbre.class);
                intent.putParcelableArrayListExtra(LISTA_TIMBRE, timbreLista);
                startActivityForResult(intent, REQUEST_CODE_LISTA);
            }
        });

        main_activity_btn_lista_evenimte=findViewById(R.id.main_activity_list_evenimente);
        main_activity_btn_lista_evenimte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(getApplicationContext(), R.string.redirect,Toast.LENGTH_SHORT).show();
                Intent newIntent = new Intent(MainActivity.this, ListaEvenimenteFilatelisti.class);
                startActivity(newIntent);
            }
        });

        main_activity_btn_json= findViewById(R.id.buttonJSON);
        main_activity_btn_json.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), JsonActivity.class);
                startActivityForResult(intent, REQUEST_CODE_LISTA);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REQUEST_CODE_ADAUGA && resultCode == RESULT_OK && data != null) {
            Timbru timbru = data.getParcelableExtra(AdaugareTimbre.ADAUGA_TIMBRU);
            if(timbru != null) {
                timbreLista.add(timbru);
            }
        } else if (requestCode == REQUEST_CODE_LISTA && resultCode == RESULT_OK && data != null) {
            timbreLista = data.getParcelableArrayListExtra(LISTA_TIMBRE);
        }
    }
}