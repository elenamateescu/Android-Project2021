package com.example.menabil_elida_mateescu_elena_1082;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.menabil_elida_mateescu_elena_1082.utils.Timbru;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AdaugareTimbre extends AppCompatActivity {

    public static final String DATE_FORMAT = "dd-MM-yyyy";
    public static final String ADAUGA_TIMBRU= "adauga";
    public static final int RESULT_DELETE = 4;

    EditText adauga_timbru_edt_denumire;
    EditText adauga_timbru_edt_serie;
    EditText adauga_timbru_edt_pret;
    TextView adauga_timbru_tv_Data;
    DatePickerDialog.OnDateSetListener listener;
    Spinner adauga_timbru_spn_Uzura;
    Button adauga_timbru_btn_adauga;
    Button adauga_timbru_btn_sterge;
    Intent intent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adaugare_timbre);
        initComponents();
        intent=getIntent();
        if(intent.hasExtra(ListaTimbre.UPDATE_OBIECT)) {
            Timbru timbru = getIntent().getParcelableExtra(ListaTimbre.UPDATE_OBIECT);
            updateUI(timbru);
        }
    }

    private void initComponents() {
        adauga_timbru_edt_denumire=findViewById(R.id.adauga_timbru_activity_denumire);
        adauga_timbru_edt_serie=findViewById(R.id.adauga_timbru_activity_serie);
        adauga_timbru_tv_Data=findViewById(R.id.adauga_timbru_tv_data);
        adauga_timbru_tv_Data.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog dialog = new DatePickerDialog(AdaugareTimbre.this,
                    listener, year, month, day);
            dialog.show();
        });

        listener = (view, year, month, dayOfMonth) -> {
            String data = dayOfMonth + "-" + month + "-" + year;
            adauga_timbru_tv_Data.setText(data);
        };
        adauga_timbru_edt_pret=findViewById(R.id.adauga_timbru_activity_pret);
        adauga_timbru_spn_Uzura=findViewById(R.id.adauga_timbru_spn_uzura);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getApplicationContext(), R.array.tip_uzura,
                android.R.layout.simple_spinner_dropdown_item);
        adauga_timbru_spn_Uzura.setAdapter(adapter);
        adauga_timbru_btn_adauga=findViewById(R.id.adauga_timbru_activity_btn_adauga);
        adauga_timbru_btn_adauga.setOnClickListener(v -> {
            if(validate()) {
                Timbru timbru = createObiectFromView();
                intent.putExtra(ADAUGA_TIMBRU, timbru);
                setResult(RESULT_OK, intent);
                finish();
            }
        });




    }

    private boolean validate() {
        if(adauga_timbru_edt_denumire.getText() == null || adauga_timbru_edt_denumire.getText().toString().trim().isEmpty()) {
            Toast.makeText(getApplicationContext(), R.string.adauga_timbru_denumire_error_message, Toast.LENGTH_LONG).show();
            return false;
        } else   if(adauga_timbru_edt_serie.getText() == null || adauga_timbru_edt_serie.getText().toString().trim().isEmpty()) {
            Toast.makeText(getApplicationContext(), R.string.numar_inventar_error_message, Toast.LENGTH_LONG).show();
            return false;
        } else   if(adauga_timbru_edt_pret.getText() == null || adauga_timbru_edt_pret.getText().toString().trim().isEmpty()) {
            Toast.makeText(getApplicationContext(), R.string.adauga_timbru_error_pret, Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }

    private Timbru createObiectFromView() {
        String denumire = adauga_timbru_edt_denumire.getText().toString();
        String serie = adauga_timbru_edt_serie.getText().toString();
        Date data = null;
        try {
            data = new SimpleDateFormat(DATE_FORMAT, Locale.US).parse(adauga_timbru_tv_Data.getText().toString());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        double pret = Double.parseDouble(adauga_timbru_edt_pret.getText().toString());
        String uzura = adauga_timbru_spn_Uzura.getSelectedItem().toString();
        return new Timbru(denumire, serie, data, pret, uzura);
    }

    private void updateUI(Timbru timbru)
    {
        adauga_timbru_edt_denumire.setText(timbru.getDenumire());
        adauga_timbru_edt_serie.setText(timbru.getSerieTimbru());
        adauga_timbru_tv_Data.setText(new SimpleDateFormat(DATE_FORMAT, Locale.US).format(timbru.getDataCreatiei()));
        adauga_timbru_edt_pret.setText(String.valueOf(timbru.getPret()));
        ArrayAdapter adapter = (ArrayAdapter) adauga_timbru_spn_Uzura.getAdapter();
        for(int i = 0; i < adapter.getCount(); i++) {
            if(adapter.getItem(i).equals(timbru.getUzura())) {
                adauga_timbru_spn_Uzura.setSelection(i);
            }
        }



    }


}